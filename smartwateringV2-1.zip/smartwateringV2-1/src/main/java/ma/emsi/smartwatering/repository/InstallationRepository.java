package ma.emsi.smartwatering.repository;

import org.springframework.data.jpa.repository.JpaRepository;


import ma.emsi.smartwatering.model.Installation;

public interface InstallationRepository extends JpaRepository<Installation, Long>{

}
	